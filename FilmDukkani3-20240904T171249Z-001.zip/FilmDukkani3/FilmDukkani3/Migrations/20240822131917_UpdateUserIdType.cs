﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FilmDukkani3.Migrations
{
    /// <inheritdoc />
    public partial class UpdateUserIdType : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
    name: "UserId",
    table: "Orders",
    type: "nvarchar(450)",
    nullable: false,
    oldClrType: typeof(int),
    oldType: "int");

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
