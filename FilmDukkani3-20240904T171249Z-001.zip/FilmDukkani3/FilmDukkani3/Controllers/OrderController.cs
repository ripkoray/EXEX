﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FilmDukkani3.Data;
using FilmDukkani3.Models;
using System.Linq;
using System.Threading.Tasks;
using FilmDukkani3.Models;
using FilmDukkani3.Data;
using FilmDukkani3.Interfaces;
using System.Security.Claims;

[Authorize]
public class OrderController : Controller
{
    private readonly FilmDukkaniContext _context;
    private readonly UserManager<IdentityUser> _userManager;
    private readonly IOrderRepository _orderRepository;
    private readonly ICartRepository _cartRepository;

    public OrderController(UserManager<IdentityUser> userManager, FilmDukkaniContext context,IOrderRepository orderRepository,ICartRepository cartRepository)
    {
        _context = context;
        _userManager = userManager;
        _orderRepository = orderRepository;
        _cartRepository = cartRepository;
    }

    public async Task<IActionResult> Index()
    {
        //var user = await _userManager.GetUserAsync(User);
        //var orders = _context.Orders
        //    .Where(o => o.UserId == user.Id)
        //    .OrderByDescending(o => o.OrderDate)
        //    .ToList();

        var userId = _userManager.GetUserId(User); // Kullanıcı ID'sini al
        var orders = _orderRepository.GetOrdersByUserId(userId); // Kullanıcının siparişlerini al
        return View(orders);

    }

    [HttpPost]
    //public IActionResult CreateOrder()
    //{
    //    var userId = _userManager.GetUserId(User); // Kullanıcı Id'sini al
    //    var cartItems = _cartRepository.GetCartItems(userId); // Sepet öğelerini al
    //    if (cartItems == null || !cartItems.Any())
    //    {
    //        return RedirectToAction("Cart");
    //    }

    //    var order = new Order
    //    {
    //        UserId = userId,
    //        OrderDate = DateTime.Now,
    //        Status = "Pending",
    //        OrderItems = cartItems.Select(item => new OrderItem
    //        {
    //            FilmId=item.FilmId,
    //            FilmTitle = item.Film.Title,
    //            Price = item.Film.Price,
    //            Quantity = item.Quantity
    //        }).ToList()
    //    };

    //    _orderRepository.AddOrder(order); // Siparişi veritabanına ekle
    //    //_cartRepository.ClearCart(userId); //Sepeti temizle ama clearcart hata veriyor 

    //    return RedirectToAction("OrderSuccess");
    //}

    [Route("Details/{id}")]
    public IActionResult OrderDetails(int id)
    {
        var order = _orderRepository.GetOrderById(id);
        if (order == null)
        {
            return NotFound();
        }
        return View(order);
    }

    //public IActionResult Checkout()
    //{

    //    var cartId = HttpContext.Session.GetString("CartId");
    //    var cartItems = _cartRepository.GetCartItems(cartId);

    //    if (!cartItems.Any())
    //    {
    //        ModelState.AddModelError("", "Sepetinizde ürün yok.");
    //        return RedirectToAction("Index", "Cart");
    //    }

    //    // userId'yi buradan alıyoruz.
    //    var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

    //    // Eğer userId boşsa, bir hata döndürebiliriz.
    //    if (string.IsNullOrEmpty(userId))
    //    {
    //        ModelState.AddModelError("", "Kullanıcı kimliği alınamadı.");
    //        return RedirectToAction("Index", "Cart");
    //    }

    //    var order = new Order
    //    {
    //        UserId = userId,
    //        OrderDate = DateTime.Now,
    //        DeliveryDate = DateTime.Now.AddDays(3),
    //        Status = "Sipariş Alındı",
    //        OrderItems = cartItems.Select(ci => new OrderItem
    //        {
    //            FilmId = ci.FilmId,
    //            FilmTitle = ci.Film.Title,
    //            Quantity = ci.Quantity,
    //            Price = ci.Film.Price
    //        }).ToList()
    //    };

    //    _orderRepository.AddOrder(order);
    //    _cartRepository.ClearCart();

    //    return RedirectToAction("OrderComplete");
    //}

    [HttpPost]
    public IActionResult OrderComplete()
    {
        #region hatali olabilir
        //var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        //if (userId == null)
        //{
        //    return RedirectToAction("Login", "Account");
        //}

        //var cart = _cartRepository.GetCart();
        //if (cart == null || !cart.CartItems.Any())
        //{
        //    // Sepet boşsa veya hata varsa kullanıcıyı geri yönlendir
        //    return RedirectToAction("Index", "Cart");
        //}

        //var order = new Order
        //{
        //    UserId = userId,
        //    OrderDate = DateTime.Now,
        //    DeliveryDate = DateTime.Now.AddDays(7),
        //    Status = "Processing",
        //    OrderItems = cart.CartItems.Select(item => new OrderItem
        //    {
        //        FilmId = item.Film.FilmId,
        //        Quantity = item.Quantity,
        //        Price = item.Film.Price
        //    }).ToList()
        //};

        //// Siparişi kaydet
        //_orderRepository.SaveOrder(order);

        //// Sepeti temizle
        //_cartRepository.ClearCart();

        //// Sipariş özetine yönlendir
        //return RedirectToAction("OrderSummary", new { orderId = order.OrderId }); 
        #endregion
        var userId = _userManager.GetUserId(User); // Kullanıcının ID'sini al
        if (userId == null)
        {
            return RedirectToAction("Login", "Account"); // Giriş yapılmamışsa yönlendir
        }

        // Siparişi kaydet
        var order = new Order
        {
            UserId = userId,
            OrderDate = DateTime.Now,
            // Diğer sipariş bilgilerini doldur
        };

        _orderRepository.SaveOrder(order);
        return RedirectToAction("Orders");

    }

    public IActionResult MyOrders()
    {
        var userId = _userManager.GetUserId(User); // Kullanıcı ID'sini al
        var orders = _orderRepository.GetOrdersByUserId(userId); // Siparişleri al
        return View(orders); // View'e gönder
    }


}
