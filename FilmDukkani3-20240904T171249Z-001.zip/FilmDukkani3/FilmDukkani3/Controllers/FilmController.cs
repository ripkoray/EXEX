﻿using Microsoft.AspNetCore.Mvc;
using FilmDukkani3.Data;
using FilmDukkani3.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using FilmDukkani3.Models;
using FilmDukkani3.Data;
using FilmDukkani3.ViewModels;
using Microsoft.AspNetCore.Hosting;
using FilmDukkani3.Interfaces;

namespace FilmDukkani.Controllers
{
    public class FilmController : Controller
    {
        private readonly FilmDukkaniContext _context;
        private readonly IFilmRepository _filmRepository;

        public FilmController(FilmDukkaniContext context,IFilmRepository filmRepository)
        {
            _context = context;
            _filmRepository=filmRepository;
        }

        public IActionResult Details(int id)
        {
            var film = _filmRepository.Films.FirstOrDefault(f => f.FilmId == id);
            if (film == null)
            {
                return NotFound();
            }
            return View(film);
        }




        // GET: Film/Create

        public IActionResult Create()
        {
            return View();
        }

        // POST: Film/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(FilmViewModel model)
        {
            if (ModelState.IsValid)
            {


                var film = new Film
                {
                    Title = model.Title,
                    Description = model.Description,
                    Director = model.Director,
                    Genre = model.Genre,
                    RealiseDate = model.ReleaseDate,
                    Price = model.Price,
                    PosterUrl= model.PosterUrl,

                };

                _context.Add(film);
                _context.SaveChangesAsync();
                return RedirectToAction("Index", "Films");
            }

            return View(model);
        }

        public IActionResult Delete()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var film = await _context.Filmler
                .FirstOrDefaultAsync(m => m.Id == id);
            if (film == null)
            {
                return NotFound();
            }

            return View(film);
        }

        public IActionResult Index()
        {
            var films = _filmRepository.GetAllFilms();
            return View(films);
        }
    }
}
