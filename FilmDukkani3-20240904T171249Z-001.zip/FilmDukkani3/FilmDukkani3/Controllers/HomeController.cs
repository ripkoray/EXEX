using FilmDukkani3.Data;
using FilmDukkani3.Interfaces;
using FilmDukkani3.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Security.Claims;

namespace FilmDukkani3.Controllers
{
    public class HomeController : Controller
    {
        private readonly FilmDukkaniContext _context;
        private readonly ICartService _cartService;

        public HomeController(FilmDukkaniContext context,ICartService cartService)
        {
            _context = context;
            _cartService= cartService;
        }

        public async Task<IActionResult> Index()
        {
            var filmler = await _context.Filmler.ToListAsync();
            return View(filmler);
        }

    }
}
