﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Stripe;
using Stripe.Checkout;
using System.Collections.Generic;
using System.Threading.Tasks;
using FilmDukkani3.Models;
using FilmDukkani3.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using FilmDukkani3.Data;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.AspNetCore.Authorization;
using FilmDukkani3.ViewModels;
using FilmDukkani3.Interfaces.Class;
using Stripe.Climate;
using FilmDukkani3.Interfaces;

namespace FilmDukkani3.Controllers
{

    public class PaymentController : Controller
    {
        private readonly FilmDukkaniContext _context;
        private readonly ICartService _cartService;
        private readonly UserManager<IdentityUser> _userManager;

        public PaymentController(FilmDukkaniContext context, ICartService cartService,UserManager<IdentityUser> userManager)
        {
            _context=context;
            _cartService=cartService;
            _userManager=userManager;
        }

        [HttpGet]
        public IActionResult Checkout(int filmId)
        {
            // filmId ile film detaylarını çekebilir ve PaymentViewModel'e ekleyebiliriz
            var paymentViewModel = new PaymentViewModel
            {
                FilmId = filmId
            };

            return View(paymentViewModel);
        }

        [HttpPost]
        public IActionResult Checkout(PaymentViewModel model)
        {
            if (ModelState.IsValid)
            {
                var cart = _cartService.GetCartByUserId(_userManager.GetUserId(User));

                if (cart != null&& cart.CartItems.Any())
                {
                    var order = new FilmDukkani3.Models.Order
                    {
                        UserId = _userManager.GetUserId(User),
                        OrderDate = DateTime.Now,
                        Status = "Ödeme Bekleniyor",
                        DeliveryDate = DateTime.Now.AddDays(7),
                        Price = cart.TotalPrice,
                        IsDelivered = false,
                        FilmName=GetFilmNamesFromCart(cart),
                        OrderItems = new List<OrderItem>(),


                    };
                    _context.Orders.Add(order);
                    _context.SaveChanges();

                    foreach (var item in cart.CartItems)
                    {
                        var orderItem = new OrderItem
                        {
                            OrderId=order.Id,
                            FilmId = item.FilmId,
                            Quantity = item.Quantity,
                            Price = item.Price,
                            FilmTitle = item.Film.Title
                        };

                        order.OrderItems.Add(orderItem);
                    }

                    order.FilmName = order.OrderItems.FirstOrDefault()?.FilmTitle;

                    _context.Orders.Add(order);
                    _context.SaveChanges();
                    //checkout ödeme yaptıktan sonra hata veriyor. 
                    var cartToDelete = _context.Carts.FirstOrDefault(c => c.Id == cart.Id);
                    if (cartToDelete != null)
                    {
                        _context.Carts.Remove(cartToDelete);
                        _context.SaveChanges();
                    }
                    
                    _context.Remove(cart.Id); //ClearCart olması lazım 
                    _context.SaveChanges();
                    return RedirectToAction("Success");
                }

                ModelState.AddModelError("", "Sepetinizde ürün bulunmuyor.");

            }

            return View(model);
        }

        public IActionResult Success()
        {
            return View();
        }

        //toodoo: ödeme işlemleri yapilcak 
        private string GetFilmNamesFromCart(Cart cart)
        {
            return string.Join(", ", cart.CartItems.Select(c => c.Film.Title));
        }
    }
}