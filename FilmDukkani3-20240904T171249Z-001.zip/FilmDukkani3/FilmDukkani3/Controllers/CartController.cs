﻿using FilmDukkani3.Interfaces;
using FilmDukkani3.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using Stripe;
using FilmDukkani3.ViewModels;
using FilmDukkani3.Data;
using FilmDukkani3.Models;
using FilmDukkani3.Interfaces.Class;
using FilmDukkani3.Sessions;
using Microsoft.CodeAnalysis.Elfie.Serialization;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using NuGet.ContentModel;
using Microsoft.EntityFrameworkCore;

namespace FilmDukkani3.Controllers
{
    public class CartController : Controller
    {
        private readonly ICartService _cartService;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IFilmRepository _filmRepository;
        private readonly FilmDukkaniContext _context;

        public CartController(ICartService cartService, UserManager<IdentityUser> userManager, IFilmRepository filmRepository, FilmDukkaniContext context)
        {
            _cartService = cartService;
            _userManager = userManager;
            _filmRepository = filmRepository;
            _context = context;
        }


        public IActionResult Cart()
        {
            var sepetId = HttpContext.Session.GetString("CartId");
            if (string.IsNullOrEmpty(sepetId))
            {
                return View("SepetBoş");
            }

            var sepet = _context.Carts
                .Include(s => s.CartItems)
                .ThenInclude(si => si.Film)
                .FirstOrDefault(s => s.Id == int.Parse(sepetId));

            if (sepet == null)
            {
                return View("SepetBoş");
            }

            return View(sepet);
        }



        public IActionResult Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var cart = _cartService.GetCartByUserId(userId);

            var model = new CartViewModel
            {
                CartItems = cart.CartItems.Select(i => new CartItemViewModel
                {
                    Film = _filmRepository.GetFilmById(i.FilmId),
                    Quantity = i.Quantity,
                    Price = i.Price
                }).ToList(),
                TotalPrice = _cartService.GetCartTotal(userId)
            };

            return View(model);
        }
        public IActionResult AddToCart(int filmId, int quantity)
        {
            var userId = _userManager.GetUserId(User);
            _cartService.AddItemToCart(userId, filmId, quantity);
            return RedirectToAction("Index");
        }


        [HttpPost]
        public IActionResult RemoveFromCart(int cartItemId)

        {  
            var cartItem = _context.CartItems.SingleOrDefault(ci => ci.Id == cartItemId);

            
            if (cartItem == null)
            {
                return NotFound("Sepet öğesi bulunamadı.");
            }

            
            _context.CartItems.Remove(cartItem);
            _context.SaveChanges();

            
            return RedirectToAction("Index");

            //sepetten ürün silinmiyo veri tabanında buyuk ihtimal sıkıntı var
        }
    }
}
