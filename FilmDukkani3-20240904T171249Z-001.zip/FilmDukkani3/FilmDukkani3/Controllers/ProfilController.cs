﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FilmDukkani3.Data;
using FilmDukkani3.Models;
using System.Threading.Tasks;
using FilmDukkani3.Data;
using FilmDukkani3.ViewModels;

[Authorize]
public class ProfilController : Controller
{
    private readonly UserManager<IdentityUser> _userManager;
    private readonly FilmDukkaniContext _context;

    public ProfilController(UserManager<IdentityUser> userManager, FilmDukkaniContext context)
    {
        _userManager = userManager;
        _context = context;
    }

    public async Task<IActionResult> Index()
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null)
        {
            return NotFound();
        }

        var orders = await _context.Orders
            .Include(o => o.Film)
            .Where(o => o.UserId == user.Id)
            .ToListAsync();

        var model = new ProfilViewModel
        {
            User = user,
            Orders = orders
        };

        return View(model);
    }
}
