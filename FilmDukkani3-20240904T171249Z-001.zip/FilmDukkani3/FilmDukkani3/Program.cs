using FilmDukkani3.Data;
using FilmDukkani3.Interfaces;
using FilmDukkani3.Interfaces.Class;
using FilmDukkani3.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Stripe;
using System.Configuration;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Session'�n aktif kalma s�resi
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true; // GDPR gereksinimleri i�in �nemli
});

//builder.Services.AddDistributedMemoryCache();
//builder.Services.AddSession();


//Identity

//builder.Services.AddDbContext<FilmDukkaniContext>(options =>
//    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));



builder.Services.AddDbContext<FilmDukkaniContext>(options =>
{
    options.UseSqlServer("Server=RIP;database=filmdukkanidb3;Trusted_Connection=True;TrustServerCertificate=True;");
});


builder.Services.AddIdentity<IdentityUser, IdentityRole>()
    .AddEntityFrameworkStores<FilmDukkaniContext>()
    .AddDefaultTokenProviders();


// Add services to the container.
builder.Services.AddControllersWithViews();



builder.Services.Configure<IdentityOptions>(options =>
{
    options.Password.RequireDigit = false;
    options.Password.RequiredLength = 6;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequireUppercase = false;
    options.Password.RequireLowercase = false;
});

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.LogoutPath = "/Account/Logout";
    options.AccessDeniedPath = "/Account/AccessDenied";
});




builder.Services.AddScoped<IFilmRepository, FilmRepository>();
//builder.Services.AddScoped<Cart>(sp => SessionCart.GetCart(sp));
builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
builder.Services.AddScoped<IOrderRepository,OrderRepository>();
builder.Services.AddScoped<ICartRepository, CartRepository>();
builder.Services.AddScoped<ICartService, CartService>();

var app = builder.Build();
// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();



app.UseEndpoints(endpoints =>
{

    endpoints.MapControllerRoute(
      name: "controllers",
      pattern: "{controller=Home}/{action=Index}/{id?}"
    );



    endpoints.MapControllerRoute(
      name: "default",
   pattern: "{controller=Home}/{action=Index}/{id?}"
   );
});



StripeConfiguration.ApiKey = builder.Configuration.GetSection("Stripe")["SecretKey"];


app.Run();




//todoo: filmler sepete ekleniyor fakat sepete hangi filmler eklersek ekleyelim 2ser tane ekliyor ve �deme sayfas�ndan siparislerime gecince siparis �zetleri d�sm�yor.




//todoo: kullanici sepet i�lemlerinde sepete �r�n ekledi�i zaman hata veriyor 