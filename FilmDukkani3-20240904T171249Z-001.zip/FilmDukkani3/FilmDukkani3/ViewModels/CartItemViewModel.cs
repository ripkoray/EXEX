﻿using FilmDukkani3.Models;

namespace FilmDukkani3.ViewModels
{
    public class CartItemViewModel
    {

        public Film Film { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
    }
}
