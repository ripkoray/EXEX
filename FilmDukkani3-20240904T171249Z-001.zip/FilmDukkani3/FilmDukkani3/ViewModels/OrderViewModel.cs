﻿namespace FilmDukkani3.ViewModels
{
    public class OrderViewModel
    {
        public string FilmName { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DeliveryDate { get; set; }
        public string Status { get; set; }
        public List<OrderViewModel> OrderItems { get; set;}
    }

    public class OrderItemViewModel
    {
        public string FilmTitle { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
    }
}
