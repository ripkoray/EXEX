﻿using System.ComponentModel.DataAnnotations;

namespace FilmDukkani3.ViewModels
{
    public class PaymentViewModel
    {
        public int FilmId { get; set; }

        [Required(ErrorMessage = "Kart numarası gereklidir.")]
        [CreditCard(ErrorMessage = "Geçersiz kart numarası.")]
        [Display(Name = "Kart Numarası")]
        public string CardNumber { get; set; }

        [Required(ErrorMessage = "Son kullanma tarihi gereklidir.")]
        [Display(Name = "Son Kullanma Tarihi")]
        public string ExpiryDate { get; set; }

        [Required(ErrorMessage = "CVV gereklidir.")]
        [Display(Name = "CVV")]
        public string CVV { get; set; }

        [Required(ErrorMessage = "Kart sahibinin adı gereklidir.")]
        [Display(Name = "Kart Sahibi Adı")]
        public string CardHolderName { get; set; }
    }
}
