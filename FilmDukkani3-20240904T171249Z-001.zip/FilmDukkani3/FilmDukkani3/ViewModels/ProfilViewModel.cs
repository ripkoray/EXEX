﻿using FilmDukkani3.Models;
using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;

namespace FilmDukkani3.ViewModels
{
    public class ProfilViewModel
    {
        public IdentityUser User { get; set; }
        public List<Order> Orders { get; set; }
    }
}
