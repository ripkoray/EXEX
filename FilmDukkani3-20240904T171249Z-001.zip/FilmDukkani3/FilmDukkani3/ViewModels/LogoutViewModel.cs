﻿namespace FilmDukkani3.ViewModels
{
    public class LogoutViewModel
    {
    }
}
