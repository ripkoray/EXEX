﻿using System.ComponentModel.DataAnnotations;

namespace FilmDukkani3.ViewModels
{
    public class FilmViewModel
    {
        [Required]
        public string Title { get; set; }

        [Required]
        public string Description { get; set; }

        public string Director { get; set; }

        public string Genre { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime ReleaseDate { get; set; }

        [Required]
        [Range(0, 1000)]
        public decimal Price { get; set; }
        public string PosterUrl { get; set; }  // Poster için dosya yükleme
        


    }


}
