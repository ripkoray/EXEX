﻿using System.ComponentModel.DataAnnotations;

namespace FilmDukkani3.Models
{
    public class Film
    {

        public int Id { get; set; }

        public int FilmId { get; set; }

        [Required]
        [StringLength(100)]
        public string Title { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public decimal Price { get; set; }

        public string Director { get; set; }

        public string Genre { get; set; }
        public DateTime RealiseDate { get; set; }
        public string PosterUrl { get; set; }
        public bool New {get;set;}
        public bool Populer { get; set; }

        public ICollection<OrderItem> OrderItems { get; set; }
        
    }

}
