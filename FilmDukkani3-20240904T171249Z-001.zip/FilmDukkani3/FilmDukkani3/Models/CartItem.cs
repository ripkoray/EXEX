﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FilmDukkani3.Models
{
    public class CartItem
    {
        [Key]
        public int Id { get; set; }
        public int CartId { get; set; }

        [ForeignKey("CartId")]
        public Cart Cart { get; set; }
        public int FilmId { get; set; }
        [ForeignKey("FilmId")]
        public Film Film { get; set; }
        public int Quantity { get; set; } // Kullanıcının aldığı ürün adedi
        public decimal Price { get; set; }

    }
}
