﻿namespace FilmDukkani3.Models
{
    public class ÖdemeModel
    {
        public decimal ToplamTutar { get; set; }
        public string Adres { get; set; }
        public string KrediKartıNumarası { get; set; }
        public string SonKullanmaTarihi { get; set; }
        public string CVC { get; set; }

    }
}
