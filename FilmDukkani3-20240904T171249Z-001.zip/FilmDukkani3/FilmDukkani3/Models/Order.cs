﻿using FilmDukkani3.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FilmDukkani3.Models
{
    public class Order
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int OrderId { get; set; }

        [Required]
        public string UserId { get; set; }

        [Required]
        public int FilmId { get; set; }

        public Film Film { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime OrderDate { get; set; }

        [Required]
        public decimal Price { get; set; }

        public string Status { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime DeliveryDate { get; set; } //datetime? olabilir

        public bool IsDelivered { get; set; }
        public List<CartItem> CartItems { get; set; }

        public string FilmName { get; set; }
        public IdentityUser User { get; set; }
        public ICollection<OrderItem> OrderItems { get; set;}

        public decimal TotalPrice { get; set; }
        public int Quantity { get; set; }
    }
    public class OrderItem
    {
        public int OrderItemId { get; set; }
        public int OrderId { get; set; }
        public Order Order { get; set; }


        public int FilmId { get; set; }
        public Film Film { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public string FilmTitle { get; set; }
        
    }
}
