﻿using FilmDukkani3.Sessions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;


namespace FilmDukkani3.Models
{
    public class SessionCart:Cart
    {
        //private ISession Session { get; set; }

        //public static Cart GetCart(IServiceProvider services)
        //{
        //    ISession session = services.GetRequiredService<IHttpContextAccessor>()?.HttpContext.Session;
        //    SessionCart cart = session?.GetJson<SessionCart>("Cart") ?? new SessionCart();
        //    cart.Session = session;
        //    return cart;
        //}

        //public override void AddToCart(Film film, int quantity)
        //{
        //    base.AddToCart(film, quantity);
        //    Session.SetJson("Cart", this);
        //}

        //public override void RemoveFromCart(Film film)
        //{
        //    base.RemoveFromCart(film);
        //    Session.SetJson("Cart", this);
        //}

        //public override void Clear()
        //{
        //    base.Clear(); //_cartItems oladabilir ama hata veriyor
        //    Session.Remove("Cart");
        //}
    }
}

