﻿using FilmDukkani3.Models;

namespace FilmDukkani3.Interfaces
{
    public interface IFilmRepository
    {
        IEnumerable<Film> GetAllFilms();
        Film GetFilmById(int id);
        IEnumerable<Film> Films { get; }

    }
}
