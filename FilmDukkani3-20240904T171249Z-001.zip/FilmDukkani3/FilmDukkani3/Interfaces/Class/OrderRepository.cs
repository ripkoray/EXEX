﻿using FilmDukkani3.Data;
using FilmDukkani3.Models;
using Microsoft.EntityFrameworkCore;

namespace FilmDukkani3.Interfaces.Class
{
    public class OrderRepository : IOrderRepository
    {
        private readonly FilmDukkaniContext _context;

        public OrderRepository(FilmDukkaniContext context)
        {
            _context = context;
        }
        public void AddOrder(Order order)
        {
            _context.Orders.Add(order);
            _context.SaveChanges();
        }

        public void CreateOrder(Order order)
        {
            _context.Orders.Add(order);
            _context.SaveChanges();
        }

        public void DeleteOrder(int orderId)
        {
            var order = _context.Orders.Find(orderId);
            if (order != null)
            {
                _context.Orders.Remove(order);
                _context.SaveChanges();
            }
        }

        public Order GetOrderById(int orderId)
        {
            return _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Film) //normalde film olması gerekiyo
                .FirstOrDefault(o => o.OrderId == orderId);
        }

        public IEnumerable<Order> GetOrders()
        {
            return _context.Orders
                .Include(o => o.OrderItems)
                .Include(oi => oi.Film)
                .ToList();
        }

        public IEnumerable<Order> GetOrdersByUserId(string userId) //List<> olcak
        {
            return _context.Orders
                 .Where(o => o.UserId == userId) //userId string olmalı dedik string dönüyo ama hata veriyo
                 .Include(o => o.OrderItems)
                 .ThenInclude(oi => oi.Film)
                 .ToList();
        }

        public void SaveOrder(Order order)  //hata var kullanıcı siparişi verdikten sonra bu metod veri tabanına kaydetmesi gerekiyor fakat kaydetmiyor.
        {
            _context.Orders.Add(order);

            //foreach (var orderItem in order.OrderItems)
            //{
                
            //    _context.OrderItems.Add(orderItem); 
            //}
            _context.SaveChanges();
        }

        public void UpdateOrder(Order order)
        {
            _context.Orders.Update(order);
            _context.SaveChanges();
        }


    }
}
