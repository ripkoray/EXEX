﻿using FilmDukkani3.Data;
using FilmDukkani3.Models;

namespace FilmDukkani3.Interfaces.Class
{
    public class FilmRepository : IFilmRepository
    {
        private readonly FilmDukkaniContext _context;

        public FilmRepository(FilmDukkaniContext context)
        {
            _context = context;
        }

        public IEnumerable<Film> Films => _context.Filmler.ToList();

        public void AddFilm(Film film)
        {
            _context.Filmler.Add(film);
            _context.SaveChanges();
        }

        public void DeleteFilm(int id)
        {
            var film= GetFilmById(id);
            if (film != null)
            {
                _context.Filmler.Remove(film);
                _context.SaveChanges();
            }
        }

        public IEnumerable<Film> GetAllFilms()
        {
            return _context.Filmler;
        }

        public Film GetFilmById(int id)
        {
            return _context.Filmler.FirstOrDefault(f => f.FilmId == id);
        }

        public void UpdateFilm(Film film)
        {
            _context.Filmler.Update(film);
            _context.SaveChanges();
        }
    }
}
