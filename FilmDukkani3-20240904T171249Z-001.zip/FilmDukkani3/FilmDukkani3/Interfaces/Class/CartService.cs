﻿using FilmDukkani3.Models;
using Stripe;

namespace FilmDukkani3.Interfaces.Class
{
    public class CartService : ICartService
    {
        private readonly ICartRepository _cartRepository;
        private readonly IFilmRepository _filmReposirory;

        public CartService(ICartRepository cartRepository,IFilmRepository filmRepository)
        {
            _cartRepository= cartRepository;
            _filmReposirory = filmRepository;
        }

        public void AddItemToCart(string userId, int filmId, int quantity)
        {
            //var cart = GetOrCreateCart(userId);

            var cart = _cartRepository.GetCartByUserId(userId);

            if (cart == null)
            {
                // Sepet mevcut değilse yeni bir sepet oluştur
                cart = new Cart
                {
                    UserId = userId,
                    CartItems = new List<CartItem>()
                };
                _cartRepository.CreateCart(cart);
            }

            var cartItem = cart.CartItems.FirstOrDefault(ci => ci.FilmId == filmId);

            if (cartItem != null)
            {
                cartItem.Quantity += quantity;
            }
            else
            {
                cart.CartItems.Add(new CartItem
                {
                    FilmId = filmId,
                    Quantity = quantity,
                    Price =_filmReposirory.GetFilmById(filmId).Price // film fiyatını belirle
            });
            }

            _cartRepository.UpdateCart(cart);
        }

        public void ClearCart(string userId)
        {
            var cart = _cartRepository.GetCartByUserId(userId);

            if (cart != null)
            {
                cart.CartItems.Clear();
                _cartRepository.UpdateCart(cart);
            }
        }

        public decimal GetCartTotal(string userId)
        {
            var cart = _cartRepository.GetCartByUserId(userId);
            if (cart == null) return 0;

            return cart.CartItems.Sum(item => item.Quantity * item.Price);
        }

        public Cart GetOrCreateCart(string userId)
        {
            var cart = _cartRepository.GetCartByUserId(userId);

            if (cart == null)
            {
                cart = new Cart { UserId = userId };
                _cartRepository.AddCart(cart);
            }

            return cart;
        }

        public void RemoveFromCart(string userId, int filmId)
        {
            var cart = _cartRepository.GetCartByUserId(userId);

            if (cart != null)
            {
                var cartItem = cart.CartItems.FirstOrDefault(i => i.FilmId == filmId);

                if (cartItem != null)
                {
                    cart.CartItems.Remove(cartItem);
                    _cartRepository.UpdateCart(cart);
                }
            }
        }

        public void SaveCart(Cart cart)
        {
            
        }

        public void UpdateCartItem(string userId, int filmId, int quantity)
        {
            var cart = _cartRepository.GetCartByUserId(userId);

            if (cart != null)
            {
                var cartItem = cart.CartItems.FirstOrDefault(i => i.FilmId == filmId);

                if (cartItem != null)
                {
                    cartItem.Quantity = quantity;
                    _cartRepository.UpdateCart(cart);
                }
            }
        }

        public Cart GetCartByUserId(string userId)
        {
            // Kullanıcının sepetini repository üzerinden getir
            var cart = _cartRepository.GetCartByUserId(userId);

            // Eğer sepet yoksa yeni bir sepet oluştur
            if (cart == null)
            {
                cart = new Cart
                {
                    UserId = userId,
                    CartItems = new List<CartItem>()
                };

                _cartRepository.CreateCart(cart);
            }

            return cart;
        }
    }
}
