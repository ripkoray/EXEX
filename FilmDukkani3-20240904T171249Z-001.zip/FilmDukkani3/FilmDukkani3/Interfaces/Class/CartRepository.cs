﻿using FilmDukkani3.Data;
using FilmDukkani3.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using NuGet.ContentModel;
using System.Linq;

namespace FilmDukkani3.Interfaces.Class
{
    public class CartRepository : ICartRepository
    {
        
        private readonly ISession _session;
        private readonly FilmDukkaniContext _context;
        private readonly ICartRepository _cartRepository;

        public CartRepository(FilmDukkaniContext context)
        {
            _context = context;
        }

        public void AddCart(Cart cart)
        {
            _context.Carts.Add(cart);
            _context.SaveChanges();
        }

        public void CreateCart(Cart cart)
        {
            _context.Carts.Add(cart);
            _context.SaveChanges();
        }

        public Cart GetCartByUserId(string userId)
        {
            return _context.Carts
            .Include(c => c.CartItems)
            .ThenInclude(ci => ci.Film)
            .FirstOrDefault(c => c.UserId == userId);
        }

        public void RemoveCart(int cartItemId) //Cart cart olucak
        {
            var cartItem = _context.CartItems.FirstOrDefault(c => c.Id == cartItemId);
            if (cartItem != null)
            {
                _context.CartItems.Remove(cartItem);
                _context.SaveChanges();
            }
            //_context.Carts.Remove(cart);
            //_context.SaveChanges();
        }

        public void UpdateCart(Cart cart)
        {
            _context.Carts.Update(cart);
            _context.SaveChanges();
        }

        #region eski hali
        //public void AddToCart(Film film, int quantity)
        //{
        //    var cart = GetCart();
        //    var cartItem = cart.CartItems.FirstOrDefault(c => c.Film.FilmId == film.FilmId);

        //    if (cartItem == null)
        //    {
        //        cart._cartItems.Add(new CartItem { Film = film, Quantity = quantity });
        //    }
        //    else
        //    {
        //        cartItem.Quantity += quantity;
        //    }

        //    SaveCart(cart);
        //}

        //public void ClearCart()
        //{
        //    SaveCart(new Cart());
        //}

        //public Cart GetCart()
        //{
        //    var cart = _session.GetString("Cart");
        //    return string.IsNullOrEmpty(cart) ? new Cart() : JsonConvert.DeserializeObject<Cart>(cart);
        //}

        //public List<CartItem> GetCartItems(string cartId)
        //{
        //    return _context.CartItems
        //         .Where(c => c.CartId == cartId)
        //         .Include(c => c.Film)
        //         .ToList();
        //}

        //public decimal GetTotal()
        //{
        //    var cart = GetCart();
        //    return cart.CartItems.Sum(c => c.Film.Price * c.Quantity);
        //}

        //public void RemoveFromCart(CartItem cartItem)
        //{
        //    var cart = GetCart();
        //    var cartItemToRemove = _context.CartItems.FirstOrDefault(c => c.CartItemId == cartItem.CartItemId);

        //    if (cartItemToRemove != null)
        //    {
        //        _context.CartItems.Remove(cartItemToRemove);
        //        _context.SaveChanges();
        //    }
        //}
        //public void SaveCart(Cart cart)
        //{
        //    _session.SetString("Cart", JsonConvert.SerializeObject(cart));
        //} 
        #endregion
    }
}
