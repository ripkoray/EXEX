﻿using FilmDukkani3.Models;

namespace FilmDukkani3.Interfaces
{
    public interface ICartRepository
    {
        //void AddToCart(Film film, int quantity);
        //void RemoveFromCart(CartItem cartItem); // Film film olacaktı 
        //Cart GetCart();
        //void ClearCart();
        //decimal GetTotal();
        //void AddMovieToBasket(int filmId);
        //void RemoveMovieFromBasket(int filmId);
        //void UpdateMovieQuantityInBasket(int filmId, int newQuantity);
        //void ClearBasket();
        //void Checkout();
        //List<CartItem> GetCartItems(string cartId);

        Cart GetCartByUserId(string userId);
        void AddCart(Cart cart);
        void UpdateCart(Cart cart);
        void RemoveCart(int cartItemId);
        void CreateCart(Cart cart);
    }
}
