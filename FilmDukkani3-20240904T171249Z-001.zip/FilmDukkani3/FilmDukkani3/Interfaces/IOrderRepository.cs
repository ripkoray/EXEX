﻿using FilmDukkani3.Models;

namespace FilmDukkani3.Interfaces
{
    public interface IOrderRepository
    {
        void CreateOrder(Order order);
        //IEnumerable<Order> GetUserOrders(string userId);

        void AddOrder(Order order);
        IEnumerable<Order> GetOrdersByUserId(string userId);
        IEnumerable<Order> GetOrders();
        Order GetOrderById(int orderId);
        void UpdateOrder(Order order);
        void DeleteOrder(int orderId);

        void SaveOrder(Order order);

       

    }

}
