﻿using FilmDukkani3.Models;

namespace FilmDukkani3.Interfaces
{
    public interface ICartService
    {
        Cart GetOrCreateCart(string userId);

        // Sepete yeni bir ürün ekler
        void AddItemToCart(string userId, int filmId, int quantity);

        // Sepetteki bir ürünü günceller (örneğin, miktarını artırır/azaltır)
        void UpdateCartItem(string userId, int filmId, int quantity);

        // Sepetten belirli bir ürünü çıkarır
        void RemoveFromCart(string userId, int filmId);

        // Sepeti tamamen temizler
        void ClearCart(string userId);

        // Sepeti veritabanına kaydeder
        void SaveCart(Cart cart);

        decimal GetCartTotal(string userId);

        Cart GetCartByUserId(string userId);


    }
}
